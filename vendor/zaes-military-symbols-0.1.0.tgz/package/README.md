# @zaes/military-symbols

MIL-STD-2525C, 2525D and 2525E (and APP-6) single-point military symbols, drawn from the
standards: frames, icons, sector modifiers and amplifiers for every symbol set, including the
point control measures.

```ts
import {renderSymbol} from '@zaes/military-symbols';

const {svg, anchor, problems} = renderSymbol('130310000011000000000000000000', {size: 40});
```

2525E codes draw out of the box. 2525D's drawings and 2525C's letter codes are separate entries,
loaded once:

```ts
import {use2525D} from '@zaes/military-symbols/2525d';
import {use2525C} from '@zaes/military-symbols/2525c'; // also loads 2525D

use2525C();
renderSymbol('SFGPUCI----E---');
```

Early development: not published yet. The code layer is [`@zaes/sidc`](../sidc).

MIT licensed; the drawings derive from Apache-2.0 work (see THIRD-PARTY-NOTICES).
