# @zaes/sidc

Read, validate and write MIL-STD-2525 symbol identification codes: the 15-character letter code of
2525C and the 20- and 30-position numeric codes of 2525D and 2525E (and APP-6 D/E). No
dependencies.

```ts
import {parseSidc} from '@zaes/sidc';

const result = parseSidc('130310000011000000000000000000');
if (result.ok) console.log(result.sidc.standard, result.sidc.symbolSet, result.problems);
```

`@zaes/sidc/catalog` lists every 2525E entity and modifier; `@zaes/sidc/2525c` converts 2525C
letter codes to 2525D codes (`convert2525C`).

MIT licensed; the 2525C crosswalk derives from Apache-2.0 work (see THIRD-PARTY-NOTICES).
